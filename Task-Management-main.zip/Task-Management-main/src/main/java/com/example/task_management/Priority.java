package com.example.task_management;

public enum Priority {
    LOW,
    MEDIUM,
    HIGH

}